"""Custom CSS for a premium SaaS / FinTech analytics dashboard look."""

CUSTOM_CSS = """
<style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');

    html, body, [class*="css"] {
        font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
    }

    /* Hide default Streamlit chrome for a cleaner product feel */
    #MainMenu {visibility: hidden;}
    footer {visibility: hidden;}

    /* ---------- Header ---------- */
    .app-header {
        background: linear-gradient(120deg, #4338CA 0%, #6D28D9 45%, #9333EA 100%);
        padding: 2rem 2.2rem;
        border-radius: 18px;
        margin-bottom: 1.4rem;
        box-shadow: 0 8px 30px rgba(99, 43, 217, 0.25);
    }
    .app-header h1 {
        color: white;
        font-size: 2.1rem;
        font-weight: 800;
        margin: 0 0 0.35rem 0;
        letter-spacing: -0.02em;
    }
    .app-header p {
        color: rgba(255,255,255,0.88);
        font-size: 1.02rem;
        margin: 0;
        font-weight: 500;
    }
    .status-pill {
        display: inline-flex;
        align-items: center;
        gap: 0.4rem;
        background: rgba(255,255,255,0.16);
        border: 1px solid rgba(255,255,255,0.3);
        color: white;
        padding: 0.3rem 0.8rem;
        border-radius: 999px;
        font-size: 0.82rem;
        font-weight: 600;
        margin-top: 0.9rem;
    }

    /* ---------- KPI cards ---------- */
    .kpi-card {
        background: var(--background-color, #ffffff);
        border: 1px solid rgba(120,120,140,0.15);
        border-radius: 16px;
        padding: 1.1rem 1.2rem;
        box-shadow: 0 2px 10px rgba(20,20,50,0.05);
        height: 100%;
    }
    .kpi-label {
        font-size: 0.78rem;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.04em;
        opacity: 0.65;
        margin-bottom: 0.3rem;
    }
    .kpi-value {
        font-size: 1.55rem;
        font-weight: 800;
        letter-spacing: -0.02em;
        margin-bottom: 0.2rem;
    }
    .kpi-delta-up { color: #16A34A; font-weight: 700; font-size: 0.85rem; }
    .kpi-delta-down { color: #DC2626; font-weight: 700; font-size: 0.85rem; }
    .kpi-delta-flat { color: #6B7280; font-weight: 700; font-size: 0.85rem; }

    /* ---------- Section headers ---------- */
    .section-title {
        font-size: 1.28rem;
        font-weight: 800;
        letter-spacing: -0.01em;
        margin: 1.6rem 0 0.6rem 0;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }
    .section-sub {
        font-size: 0.92rem;
        opacity: 0.7;
        margin-bottom: 0.9rem;
        margin-top: -0.4rem;
    }

    /* ---------- Generic card ---------- */
    .soft-card {
        background: var(--background-color, #ffffff);
        border: 1px solid rgba(120,120,140,0.15);
        border-radius: 16px;
        padding: 1.2rem 1.3rem;
        box-shadow: 0 2px 10px rgba(20,20,50,0.05);
        margin-bottom: 0.9rem;
    }

    /* ---------- Badges ---------- */
    .badge {
        display: inline-block;
        padding: 0.22rem 0.7rem;
        border-radius: 999px;
        font-size: 0.78rem;
        font-weight: 700;
    }
    .badge-green { background: #DCFCE7; color: #166534; }
    .badge-yellow { background: #FEF9C3; color: #854D0E; }
    .badge-orange { background: #FFEDD5; color: #9A3412; }
    .badge-red { background: #FEE2E2; color: #991B1B; }
    .badge-blue { background: #DBEAFE; color: #1E40AF; }
    .badge-purple { background: #F3E8FF; color: #6B21A8; }

    /* ---------- Forecast hero card ---------- */
    .forecast-hero {
        background: linear-gradient(135deg, #0F172A 0%, #1E293B 100%);
        border-radius: 20px;
        padding: 2.1rem 2rem;
        text-align: center;
        color: white;
        box-shadow: 0 10px 30px rgba(15, 23, 42, 0.35);
    }
    .forecast-hero .label {
        font-size: 0.85rem;
        letter-spacing: 0.08em;
        text-transform: uppercase;
        opacity: 0.75;
        font-weight: 700;
    }
    .forecast-hero .value {
        font-size: 3rem;
        font-weight: 800;
        letter-spacing: -0.02em;
        margin: 0.4rem 0;
    }

    /* ---------- Leaderboard / milestone rows ---------- */
    .rank-row {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 0.7rem 1rem;
        border-radius: 12px;
        background: rgba(120,120,140,0.06);
        margin-bottom: 0.5rem;
        font-weight: 600;
    }
    .milestone-card {
        border-radius: 14px;
        padding: 1rem 1.1rem;
        text-align: center;
        border: 1px solid rgba(120,120,140,0.15);
        height: 100%;
    }

    /* ---------- Alerts ---------- */
    .alert-card {
        border-radius: 12px;
        padding: 0.85rem 1.1rem;
        margin-bottom: 0.6rem;
        font-weight: 500;
        border-left: 5px solid;
    }
    .alert-critical { background: #FEF2F2; border-color: #DC2626; color: #7F1D1D; }
    .alert-warning { background: #FFFBEB; border-color: #F59E0B; color: #78350F; }
    .alert-opportunity { background: #F0FDF4; border-color: #16A34A; color: #14532D; }
    .alert-info { background: #EFF6FF; border-color: #3B82F6; color: #1E3A8A; }

    hr.divider {
        border: none;
        border-top: 1px solid rgba(120,120,140,0.2);
        margin: 1.6rem 0;
    }

    .footer-block {
        text-align: center;
        padding: 1.6rem 0 0.6rem 0;
        opacity: 0.65;
        font-size: 0.85rem;
        line-height: 1.6;
    }
</style>
"""


def inject_css(st):
    st.markdown(CUSTOM_CSS, unsafe_allow_html=True)


def kpi_card_html(label, value, delta=None, delta_direction="flat", icon=""):
    delta_class = {"up": "kpi-delta-up", "down": "kpi-delta-down", "flat": "kpi-delta-flat"}[delta_direction]
    arrow = {"up": "&#8593;", "down": "&#8595;", "flat": "&#8226;"}[delta_direction]
    delta_html = f'<div class="{delta_class}">{arrow} {delta}</div>' if delta else ""
    return f"""
    <div class="kpi-card">
        <div class="kpi-label">{icon} {label}</div>
        <div class="kpi-value">{value}</div>
        {delta_html}
    </div>
    """


def badge_html(text, color="blue"):
    return f'<span class="badge badge-{color}">{text}</span>'
