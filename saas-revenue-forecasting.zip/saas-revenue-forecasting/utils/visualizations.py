"""Reusable Plotly chart builders for the SaaS Revenue Intelligence dashboard."""

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px

SEGMENT_COLORS = {
    "AI_Assistant": "#6366F1",
    "Streaming": "#F59E0B",
    "Telecom_Hosting": "#10B981",
}
HIST_COLOR = "#6366F1"
FORECAST_COLOR = "#EC4899"
BAND_COLOR = "rgba(236, 72, 153, 0.15)"

BASE_LAYOUT = dict(
    template="plotly_white",
    font=dict(family="Inter, sans-serif", size=13),
    margin=dict(l=10, r=10, t=55, b=10),
    hovermode="x unified",
    legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
)


def _seg_color(seg, i=0):
    palette = list(SEGMENT_COLORS.values())
    return SEGMENT_COLORS.get(seg, palette[i % len(palette)])


def revenue_trajectory_chart(df, moving_avg=True, show_target=False):
    """Line chart: historical revenue (+ moving average, + target) by segment."""
    fig = go.Figure()
    for i, seg in enumerate(sorted(df["segment"].unique())):
        seg_df = df[df["segment"] == seg].sort_values("date")
        color = _seg_color(seg, i)
        fig.add_trace(go.Scatter(
            x=seg_df["date"], y=seg_df["monthly_revenue_usd"],
            mode="lines+markers", name=f"{seg}", line=dict(color=color, width=2.5),
            hovertemplate="%{x|%b %Y}<br>Revenue: $%{y:,.0f}<extra>" + seg + "</extra>",
        ))
        if moving_avg:
            ma = seg_df["monthly_revenue_usd"].rolling(3, min_periods=1).mean()
            fig.add_trace(go.Scatter(
                x=seg_df["date"], y=ma, mode="lines", name=f"{seg} (3M avg)",
                line=dict(color=color, width=1.5, dash="dot"), opacity=0.6,
                hovertemplate="%{x|%b %Y}<br>3M Avg: $%{y:,.0f}<extra></extra>",
            ))
        if show_target and "target_next_month_revenue_usd" in seg_df.columns:
            fig.add_trace(go.Scatter(
                x=seg_df["date"], y=seg_df["target_next_month_revenue_usd"],
                mode="lines", name=f"{seg} (next-mo target)",
                line=dict(color=color, width=1, dash="dash"), opacity=0.35,
            ))
    fig.update_layout(**BASE_LAYOUT, title="📈 Revenue Trajectory",
                       xaxis_title="Month", yaxis_title="Revenue (USD)",
                       xaxis=dict(rangeslider=dict(visible=True), type="date"))
    return fig


def forecast_chart(historical_df, forecast_df, segment_label):
    """Historical + forecast + prediction interval for one segment (or aggregated)."""
    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=historical_df["date"], y=historical_df["monthly_revenue_usd"],
        mode="lines+markers", name="Historical Revenue",
        line=dict(color=HIST_COLOR, width=2.5),
        hovertemplate="%{x|%b %Y}<br>Actual: $%{y:,.0f}<extra></extra>",
    ))
    if not forecast_df.empty:
        # Prediction interval band
        fig.add_trace(go.Scatter(
            x=pd.concat([forecast_df["forecast_month"], forecast_df["forecast_month"][::-1]]),
            y=pd.concat([forecast_df["upper_bound"], forecast_df["lower_bound"][::-1]]),
            fill="toself", fillcolor=BAND_COLOR, line=dict(color="rgba(0,0,0,0)"),
            name="Prediction Interval (~80%)", hoverinfo="skip",
        ))
        # Bridge line from last actual to first forecast point
        bridge_x = [historical_df["date"].iloc[-1], forecast_df["forecast_month"].iloc[0]]
        bridge_y = [historical_df["monthly_revenue_usd"].iloc[-1], forecast_df["predicted_revenue"].iloc[0]]
        fig.add_trace(go.Scatter(x=bridge_x, y=bridge_y, mode="lines",
                                  line=dict(color=FORECAST_COLOR, width=2.5, dash="dash"),
                                  showlegend=False, hoverinfo="skip"))
        fig.add_trace(go.Scatter(
            x=forecast_df["forecast_month"], y=forecast_df["predicted_revenue"],
            mode="lines+markers", name="Forecast",
            line=dict(color=FORECAST_COLOR, width=2.5, dash="dash"),
            hovertemplate="%{x|%b %Y}<br>Forecast: $%{y:,.0f}<extra></extra>",
        ))
    fig.update_layout(**BASE_LAYOUT, title=f"🔮 AI Revenue Forecast — {segment_label}",
                       xaxis_title="Month", yaxis_title="Revenue (USD)")
    return fig


def segment_bar_chart(df, metric_col, metric_label, agg="last"):
    """Bar chart comparing segments on a chosen metric (latest value or mean)."""
    if agg == "last":
        latest_date = df["date"].max()
        plot_df = df[df["date"] == latest_date].groupby("segment", as_index=False)[metric_col].sum()
    else:
        plot_df = df.groupby("segment", as_index=False)[metric_col].mean()
    plot_df = plot_df.sort_values(metric_col, ascending=False)
    colors = [_seg_color(s, i) for i, s in enumerate(plot_df["segment"])]
    fig = go.Figure(go.Bar(
        x=plot_df["segment"], y=plot_df[metric_col], marker_color=colors,
        text=plot_df[metric_col].round(2), texttemplate="%{text:,.2s}", textposition="outside",
        hovertemplate="%{x}<br>" + metric_label + ": %{y:,.2f}<extra></extra>",
    ))
    fig.update_layout(**BASE_LAYOUT, title="💼 Revenue by Segment", showlegend=False,
                       xaxis_title="Segment", yaxis_title=metric_label)
    return fig


def revenue_mix_donut(df):
    """Donut chart of latest revenue contribution by segment."""
    latest_date = df["date"].max()
    plot_df = df[df["date"] == latest_date].groupby("segment", as_index=False)["monthly_revenue_usd"].sum()
    colors = [_seg_color(s, i) for i, s in enumerate(plot_df["segment"])]
    fig = go.Figure(go.Pie(
        labels=plot_df["segment"], values=plot_df["monthly_revenue_usd"], hole=0.55,
        marker=dict(colors=colors), textinfo="label+percent",
        hovertemplate="%{label}<br>$%{value:,.0f} (%{percent})<extra></extra>",
    ))
    fig.update_layout(**BASE_LAYOUT, title="🍩 Revenue Mix", showlegend=True)
    return fig


def subscriber_flow_chart(df):
    """Line chart: active / new / churned subscribers (aggregated across filter)."""
    agg = df.groupby("date", as_index=False)[["active_subscribers", "new_subscribers", "churned_subscribers"]].sum()
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=agg["date"], y=agg["active_subscribers"], mode="lines+markers",
                              name="Active Subscribers", line=dict(color="#6366F1", width=2.5)))
    fig.add_trace(go.Scatter(x=agg["date"], y=agg["new_subscribers"], mode="lines+markers",
                              name="New Subscribers", line=dict(color="#10B981", width=2)))
    fig.add_trace(go.Scatter(x=agg["date"], y=agg["churned_subscribers"], mode="lines+markers",
                              name="Churned Subscribers", line=dict(color="#EF4444", width=2)))
    fig.update_layout(**BASE_LAYOUT, title="👥 Subscriber Flow", xaxis_title="Month", yaxis_title="Subscribers")
    return fig


def subscriber_growth_area(df):
    """Area chart of active subscriber growth over time, stacked by segment."""
    fig = px.area(df.sort_values("date"), x="date", y="active_subscribers", color="segment",
                   color_discrete_map=SEGMENT_COLORS,
                   labels={"active_subscribers": "Active Subscribers", "date": "Month"})
    fig.update_layout(**BASE_LAYOUT, title="📈 Subscriber Growth Over Time")
    return fig


def subscribers_by_segment_bar(df):
    latest_date = df["date"].max()
    plot_df = df[df["date"] == latest_date].groupby("segment", as_index=False)["active_subscribers"].sum()
    colors = [_seg_color(s, i) for i, s in enumerate(plot_df["segment"])]
    fig = go.Figure(go.Bar(x=plot_df["segment"], y=plot_df["active_subscribers"], marker_color=colors,
                            text=plot_df["active_subscribers"], textposition="outside"))
    fig.update_layout(**BASE_LAYOUT, title="👥 Active Subscribers by Segment", showlegend=False,
                       xaxis_title="Segment", yaxis_title="Active Subscribers")
    return fig


def churn_trend_chart(df):
    fig = px.line(df.sort_values("date"), x="date", y="churn_rate_pct", color="segment",
                   markers=True, color_discrete_map=SEGMENT_COLORS,
                   labels={"churn_rate_pct": "Churn Rate (%)", "date": "Month"})
    fig.update_layout(**BASE_LAYOUT, title="📉 Churn Rate Over Time")
    return fig


def churn_by_segment_bar(df):
    plot_df = df.groupby("segment", as_index=False)["churn_rate_pct"].mean().sort_values("churn_rate_pct")
    colors = [_seg_color(s, i) for i, s in enumerate(plot_df["segment"])]
    fig = go.Figure(go.Bar(x=plot_df["segment"], y=plot_df["churn_rate_pct"], marker_color=colors,
                            text=plot_df["churn_rate_pct"].round(2), textposition="outside"))
    fig.update_layout(**BASE_LAYOUT, title="📊 Average Churn Rate by Segment", showlegend=False,
                       xaxis_title="Segment", yaxis_title="Avg Churn Rate (%)")
    return fig


def arpu_trend_chart(df):
    fig = px.line(df.sort_values("date"), x="date", y="arpu_usd", color="segment",
                   markers=True, color_discrete_map=SEGMENT_COLORS,
                   labels={"arpu_usd": "ARPU (USD)", "date": "Month"})
    fig.update_layout(**BASE_LAYOUT, title="💵 ARPU Trend")
    return fig


def arpu_by_segment_bar(df):
    plot_df = df.groupby("segment", as_index=False)["arpu_usd"].mean().sort_values("arpu_usd", ascending=False)
    colors = [_seg_color(s, i) for i, s in enumerate(plot_df["segment"])]
    fig = go.Figure(go.Bar(x=plot_df["segment"], y=plot_df["arpu_usd"], marker_color=colors,
                            text=plot_df["arpu_usd"].round(1), textposition="outside"))
    fig.update_layout(**BASE_LAYOUT, title="💵 Average ARPU by Segment", showlegend=False,
                       xaxis_title="Segment", yaxis_title="ARPU (USD)")
    return fig


def arpu_vs_revenue_scatter(df):
    fig = px.scatter(df, x="arpu_usd", y="monthly_revenue_usd", color="segment",
                      color_discrete_map=SEGMENT_COLORS, size="active_subscribers",
                      hover_data=["date"],
                      labels={"arpu_usd": "ARPU (USD)", "monthly_revenue_usd": "Revenue (USD)"})
    fig.update_layout(**BASE_LAYOUT, title="💵 ARPU vs Monthly Revenue")
    return fig


def marketing_vs_revenue_scatter(df):
    fig = px.scatter(df, x="marketing_spend_usd", y="monthly_revenue_usd", color="segment",
                      color_discrete_map=SEGMENT_COLORS,
                      hover_data=["date"],
                      labels={"marketing_spend_usd": "Marketing Spend (USD)",
                               "monthly_revenue_usd": "Revenue (USD)"})
    # Manual linear trendline (avoids a statsmodels dependency for a single fitted line)
    x, y = df["marketing_spend_usd"].values, df["monthly_revenue_usd"].values
    if len(x) > 1:
        slope, intercept = np.polyfit(x, y, 1)
        x_line = np.linspace(x.min(), x.max(), 50)
        fig.add_trace(go.Scatter(x=x_line, y=slope * x_line + intercept, mode="lines",
                                  name="Trend (overall)", line=dict(color="#111827", dash="dash", width=2)))
    fig.update_layout(**BASE_LAYOUT, title="📣 Marketing Spend vs Revenue")
    return fig


def correlation_heatmap(df, cols):
    corr = df[cols].corr()
    fig = go.Figure(go.Heatmap(
        z=corr.values, x=corr.columns, y=corr.columns,
        colorscale="RdBu", zmid=0, zmin=-1, zmax=1,
        text=corr.round(2).values, texttemplate="%{text}", textfont=dict(size=9),
        hovertemplate="%{y} vs %{x}: %{z:.2f}<extra></extra>",
    ))
    layout = {**BASE_LAYOUT, "margin": dict(l=10, r=10, t=55, b=10)}
    fig.update_layout(**layout, title="🧠 Revenue Driver Intelligence — Correlation Heatmap", height=650)
    return fig


def feature_importance_chart(importances: pd.Series, top_n=15):
    top = importances.head(top_n).sort_values()
    fig = go.Figure(go.Bar(
        x=top.values, y=top.index, orientation="h",
        marker_color="#0EA5A5",
        hovertemplate="%{y}: %{x:.4f}<extra></extra>",
    ))
    fig.update_layout(**BASE_LAYOUT, title="🤖 What Drives Revenue? — Top Feature Importances",
                       xaxis_title="Importance", yaxis_title="", height=max(400, 28 * len(top)))
    return fig


def actual_vs_predicted_chart(test_predictions_df):
    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=test_predictions_df["actual"], y=test_predictions_df["predicted"],
        mode="markers", marker=dict(color="#6366F1", size=9, opacity=0.75),
        name="Test predictions",
        hovertemplate="Actual: $%{x:,.0f}<br>Predicted: $%{y:,.0f}<extra></extra>",
    ))
    lims = [test_predictions_df[["actual", "predicted"]].min().min(),
            test_predictions_df[["actual", "predicted"]].max().max()]
    fig.add_trace(go.Scatter(x=lims, y=lims, mode="lines", name="Perfect Prediction",
                              line=dict(color="#9CA3AF", dash="dash")))
    fig.update_layout(**BASE_LAYOUT, title="🎯 Actual vs Predicted Revenue (Test Set)",
                       xaxis_title="Actual Revenue (USD)", yaxis_title="Predicted Revenue (USD)")
    return fig


def residual_histogram(test_predictions_df):
    fig = px.histogram(test_predictions_df, x="residual", nbins=20,
                        color_discrete_sequence=["#6366F1"],
                        labels={"residual": "Residual (Actual - Predicted)"})
    fig.add_vline(x=0, line_dash="dash", line_color="#EF4444")
    fig.update_layout(**BASE_LAYOUT, title="📊 Distribution of Residuals", yaxis_title="Count")
    return fig


def prediction_error_over_time(test_predictions_df):
    fig = px.line(test_predictions_df.sort_values("date"), x="date", y="residual", color="segment",
                   markers=True, color_discrete_map=SEGMENT_COLORS,
                   labels={"residual": "Prediction Error (Actual - Predicted)", "date": "Month"})
    fig.add_hline(y=0, line_dash="dash", line_color="#9CA3AF")
    fig.update_layout(**BASE_LAYOUT, title="📈 Prediction Error Over Time")
    return fig


def model_comparison_bar(final_comparison: pd.DataFrame, recommended_model_name: str):
    plot_df = final_comparison.reset_index().rename(columns={"index": "Model"})
    colors = ["#EC4899" if m == recommended_model_name else "#A5B4FC" for m in plot_df["Model"]]
    fig = go.Figure(go.Bar(
        x=plot_df["Model"], y=plot_df["RMSE"], marker_color=colors,
        text=plot_df["RMSE"].map(lambda v: f"${v:,.0f}"), textposition="outside",
        hovertemplate="%{x}<br>RMSE: $%{y:,.0f}<extra></extra>",
    ))
    fig.update_layout(**BASE_LAYOUT, title="🤖 Model Comparison — Test RMSE (lower is better)",
                       showlegend=False, xaxis_title="", yaxis_title="RMSE (USD)")
    return fig
