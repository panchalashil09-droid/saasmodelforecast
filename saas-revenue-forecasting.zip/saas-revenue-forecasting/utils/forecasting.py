"""
Core forecasting logic for the SaaS Revenue Intelligence app.

This module intentionally mirrors the methodology in `saas_revenue_forecasting.ipynb`
step for step:
  - same feature engineering (lags, rolling stats, growth rates, one-hot segments)
  - same chronological (no-shuffle) train/test split
  - same candidate model set and same "majority vote across RMSE/MAE/MAPE" model
    selection rule
  - same residual-based prediction interval approach
  - same recursive multi-step forecasting logic

Keeping this logic in one shared module means both the offline training script
(`train_model.py`) and the live Streamlit app (`app.py`) use IDENTICAL
preprocessing/inference code -- so there is no drift between training and serving.
"""

import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import TimeSeriesSplit, RandomizedSearchCV
from sklearn.base import clone
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

RANDOM_STATE = 42

try:
    import xgboost as xgb
    XGB_AVAILABLE = True
except ImportError:
    XGB_AVAILABLE = False

try:
    import lightgbm as lgb
    LGB_AVAILABLE = True
except ImportError:
    LGB_AVAILABLE = False

REQUIRED_RAW_COLUMNS = {
    "date", "segment", "monthly_revenue_usd", "active_subscribers",
    "churn_rate_pct", "arpu_usd", "marketing_spend_usd",
}

DRIVER_COLS = [
    "active_subscribers", "new_subscribers", "churn_rate_pct",
    "trial_conversion_rate_pct", "arpu_usd", "marketing_spend_usd",
    "customer_acquisition_cost_usd", "support_tickets", "nps_score",
    "competitor_price_index", "tech_spending_index",
    "unemployment_rate_pct", "consumer_confidence_index",
]


# --------------------------------------------------------------------------
# Metrics
# --------------------------------------------------------------------------
def mape(y_true, y_pred):
    """Mean Absolute Percentage Error."""
    y_true, y_pred = np.array(y_true, dtype=float), np.array(y_pred, dtype=float)
    return float(np.mean(np.abs((y_true - y_pred) / y_true)) * 100)


def regression_metrics(y_true, y_pred):
    return {
        "MAE": float(mean_absolute_error(y_true, y_pred)),
        "RMSE": float(np.sqrt(mean_squared_error(y_true, y_pred))),
        "MAPE": mape(y_true, y_pred),
        "R2": float(r2_score(y_true, y_pred)),
    }


# --------------------------------------------------------------------------
# Feature engineering (identical to notebook Section 4)
# --------------------------------------------------------------------------
def engineer_features(df: pd.DataFrame):
    """
    Reproduces notebook Section 4 exactly.

    Returns
    -------
    feat_df : full engineered frame (includes warm-up rows with NaNs)
    model_df : feat_df with NaN warm-up rows dropped (ready for training/inference)
    feature_cols : ordered list of model input columns
    segment_dummy_cols : list of one-hot segment column names
    """
    df = df.copy()
    df["date"] = pd.to_datetime(df["date"])
    feat_df = df.sort_values(["segment", "date"]).reset_index(drop=True).copy()

    # ---- Date features ----
    feat_df["year"] = feat_df["date"].dt.year
    feat_df["month"] = feat_df["date"].dt.month
    feat_df["quarter"] = feat_df["date"].dt.quarter
    feat_df["month_number"] = feat_df["month"]
    feat_df["quarter_number"] = feat_df["quarter"]
    feat_df["time_index"] = feat_df.groupby("segment").cumcount()

    # ---- Lag features for revenue (per segment, past values only) ----
    g = feat_df.groupby("segment")["monthly_revenue_usd"]
    for lag in [1, 2, 3, 6, 12]:
        feat_df[f"revenue_lag_{lag}"] = g.shift(lag)

    # ---- 1-month lag for other key business variables ----
    for col in ["active_subscribers", "churn_rate_pct", "arpu_usd", "marketing_spend_usd"]:
        feat_df[f"{col}_lag_1"] = feat_df.groupby("segment")[col].shift(1)

    # ---- Rolling stats on revenue (no future leakage: window ends at T) ----
    g = feat_df.groupby("segment")["monthly_revenue_usd"]
    feat_df["revenue_rolling_mean_3"] = g.transform(lambda x: x.rolling(3).mean())
    feat_df["revenue_rolling_mean_6"] = g.transform(lambda x: x.rolling(6).mean())
    feat_df["revenue_rolling_mean_12"] = g.transform(lambda x: x.rolling(12).mean())
    feat_df["revenue_rolling_std_3"] = g.transform(lambda x: x.rolling(3).std())
    feat_df["revenue_rolling_std_6"] = g.transform(lambda x: x.rolling(6).std())

    # ---- Growth features ----
    feat_df["revenue_growth_1m"] = feat_df.groupby("segment")["monthly_revenue_usd"].pct_change(1)
    feat_df["revenue_growth_3m"] = feat_df.groupby("segment")["monthly_revenue_usd"].pct_change(3)
    feat_df["subscriber_growth"] = feat_df.groupby("segment")["active_subscribers"].pct_change(1)
    feat_df["marketing_spend_growth"] = feat_df.groupby("segment")["marketing_spend_usd"].pct_change(1)

    # ---- Segment one-hot encoding ----
    feat_df = pd.get_dummies(feat_df, columns=["segment"], prefix="segment")
    segment_dummy_cols = [c for c in feat_df.columns if c.startswith("segment_")]

    # ---- Drop warm-up rows with NaNs from lag_12 / rolling_12 ----
    model_df = feat_df.dropna().reset_index(drop=True)
    model_df = model_df.sort_values("date").reset_index(drop=True)

    exclude_cols = ["date", "target_next_month_revenue_usd"]
    feature_cols = [c for c in model_df.columns if c not in exclude_cols]

    return feat_df, model_df, feature_cols, segment_dummy_cols


# --------------------------------------------------------------------------
# Model training (identical methodology to notebook Sections 5-11)
# --------------------------------------------------------------------------
def build_candidate_models():
    models = {
        "Linear Regression": Pipeline([
            ("scaler", StandardScaler()),
            ("model", LinearRegression()),
        ]),
        "Random Forest": RandomForestRegressor(
            n_estimators=300, max_depth=6, random_state=RANDOM_STATE, n_jobs=-1
        ),
        "Gradient Boosting": GradientBoostingRegressor(
            n_estimators=200, learning_rate=0.05, max_depth=3, random_state=RANDOM_STATE
        ),
    }
    if XGB_AVAILABLE:
        models["XGBoost"] = xgb.XGBRegressor(
            n_estimators=200, learning_rate=0.05, max_depth=3,
            random_state=RANDOM_STATE, objective="reg:squarederror"
        )
    if LGB_AVAILABLE:
        models["LightGBM"] = lgb.LGBMRegressor(
            n_estimators=200, learning_rate=0.05, max_depth=3,
            random_state=RANDOM_STATE, verbosity=-1, min_child_samples=5
        )
    return models


def chronological_split(model_df: pd.DataFrame, train_frac: float = 0.8):
    """Split by date cutoff -- never randomly -- exactly like notebook Section 6."""
    model_df = model_df.sort_values("date").reset_index(drop=True)
    unique_dates = model_df["date"].unique()
    cutoff_date = unique_dates[int(len(unique_dates) * train_frac)]
    train_mask = model_df["date"] < cutoff_date
    train_df = model_df[train_mask].reset_index(drop=True)
    test_df = model_df[~train_mask].reset_index(drop=True)
    return train_df, test_df, cutoff_date


def train_and_evaluate(df: pd.DataFrame, tune: bool = True):
    """
    Full training pipeline mirroring notebook Sections 5-14.

    Returns a dict of artifacts needed by the app: final_model, feature_cols,
    segment_dummy_cols, model comparison table, cv summary, feature importances,
    residual std, test-set actual/predicted values (for accuracy charts), and
    baseline comparison.
    """
    feat_df, model_df, feature_cols, segment_dummy_cols = engineer_features(df)
    train_df, test_df, cutoff_date = chronological_split(model_df)

    X_train, y_train = train_df[feature_cols], train_df["target_next_month_revenue_usd"]
    X_test, y_test = test_df[feature_cols], test_df["target_next_month_revenue_usd"]
    X_full = model_df[feature_cols]
    y_full = model_df["target_next_month_revenue_usd"]

    # --- Baselines (Section 5) ---
    y_true_all = model_df["target_next_month_revenue_usd"]
    baseline_results = {
        "Naive (current month)": regression_metrics(y_true_all, model_df["monthly_revenue_usd"]),
        "Moving Average (3m)": regression_metrics(y_true_all, model_df["revenue_rolling_mean_3"]),
        "Seasonal Naive (lag 12)": regression_metrics(y_true_all, model_df["revenue_lag_12"]),
    }

    # --- ML models (Section 7) ---
    ml_models = build_candidate_models()
    ml_results = {}
    trained_models = {}
    for name, model in ml_models.items():
        model.fit(X_train, y_train)
        y_pred = model.predict(X_test)
        ml_results[name] = regression_metrics(y_test, y_pred)
        trained_models[name] = model

    # --- TimeSeriesSplit CV (Section 8) ---
    n_splits = min(4, max(2, len(X_full) // 10))
    tscv = TimeSeriesSplit(n_splits=n_splits)
    cv_results = {name: {"MAE": [], "RMSE": [], "MAPE": []} for name in ml_models}
    for name, model in ml_models.items():
        for tr_idx, val_idx in tscv.split(X_full):
            X_tr, X_val = X_full.iloc[tr_idx], X_full.iloc[val_idx]
            y_tr, y_val = y_full.iloc[tr_idx], y_full.iloc[val_idx]
            fold_model = clone(model)
            fold_model.fit(X_tr, y_tr)
            y_pred = fold_model.predict(X_val)
            cv_results[name]["MAE"].append(mean_absolute_error(y_val, y_pred))
            cv_results[name]["RMSE"].append(np.sqrt(mean_squared_error(y_val, y_pred)))
            cv_results[name]["MAPE"].append(mape(y_val, y_pred))

    cv_summary = pd.DataFrame({
        name: {
            "MAE_mean": np.mean(v["MAE"]), "MAE_std": np.std(v["MAE"]),
            "RMSE_mean": np.mean(v["RMSE"]), "RMSE_std": np.std(v["RMSE"]),
            "MAPE_mean": np.mean(v["MAPE"]), "MAPE_std": np.std(v["MAPE"]),
        } for name, v in cv_results.items()
    }).T

    # --- Lightweight hyperparameter tuning on best tree model (Section 9) ---
    if tune:
        tree_model_names = [n for n in ml_models if n != "Linear Regression"]
        best_tree_name = cv_summary.loc[tree_model_names, "RMSE_mean"].idxmin()

        param_distributions = {
            "Random Forest": {"n_estimators": [150, 300, 500], "max_depth": [3, 5, 8, None],
                               "min_samples_leaf": [1, 2, 4]},
            "Gradient Boosting": {"n_estimators": [100, 200, 300], "max_depth": [2, 3, 4],
                                   "learning_rate": [0.03, 0.05, 0.1]},
            "XGBoost": {"n_estimators": [100, 200, 300], "max_depth": [2, 3, 4],
                        "learning_rate": [0.03, 0.05, 0.1]},
            "LightGBM": {"n_estimators": [100, 200, 300], "max_depth": [2, 3, 4],
                         "learning_rate": [0.03, 0.05, 0.1], "min_child_samples": [3, 5, 10]},
        }
        try:
            search = RandomizedSearchCV(
                estimator=ml_models[best_tree_name],
                param_distributions=param_distributions[best_tree_name],
                n_iter=8, scoring="neg_root_mean_squared_error",
                cv=TimeSeriesSplit(n_splits=min(3, n_splits)),
                random_state=RANDOM_STATE, n_jobs=-1,
            )
            search.fit(X_full, y_full)
            tuned_model = search.best_estimator_
            tuned_model.fit(X_train, y_train)
            y_pred_tuned = tuned_model.predict(X_test)
            tuned_name = f"{best_tree_name} (Tuned)"
            ml_results[tuned_name] = regression_metrics(y_test, y_pred_tuned)
            trained_models[tuned_name] = tuned_model
        except Exception:
            pass  # tuning is a bonus step; never let it break training

    # --- Final comparison & model selection (Section 10) ---
    final_comparison = pd.DataFrame(ml_results).T.round(3).sort_values("RMSE")
    best_by_rmse = final_comparison["RMSE"].idxmin()
    best_by_mae = final_comparison["MAE"].idxmin()
    best_by_mape = final_comparison["MAPE"].idxmin()
    candidate_counts = pd.Series([best_by_rmse, best_by_mae, best_by_mape]).value_counts()
    recommended_model_name = candidate_counts.idxmax()

    best_model = trained_models[recommended_model_name]
    y_pred_best = best_model.predict(X_test)
    residual_std = float(np.std(y_test.values - y_pred_best))
    final_metrics_best = regression_metrics(y_test, y_pred_best)

    # --- Feature importance (Section 13) ---
    if hasattr(best_model, "feature_importances_"):
        importances = pd.Series(best_model.feature_importances_, index=feature_cols).sort_values(ascending=False)
    elif hasattr(best_model, "named_steps") and hasattr(best_model.named_steps.get("model", None), "coef_"):
        importances = pd.Series(np.abs(best_model.named_steps["model"].coef_), index=feature_cols).sort_values(ascending=False)
    else:
        importances = pd.Series(dtype=float)

    # --- Refit recommended model on ALL data for production use (Section 14) ---
    final_model = clone(best_model) if not hasattr(best_model, "named_steps") else best_model
    try:
        final_model = clone(best_model)
    except TypeError:
        final_model = best_model
    final_model.fit(X_full, y_full)

    # Segment-level test performance (Section 12)
    segment_metrics = {}
    for seg_col in segment_dummy_cols:
        seg_name = seg_col.replace("segment_", "")
        mask = test_df[seg_col] == 1
        if mask.sum() == 0:
            continue
        segment_metrics[seg_name] = regression_metrics(y_test[mask.values], y_pred_best[mask.values])
    segment_metrics_df = pd.DataFrame(segment_metrics).T.round(3)

    test_predictions_df = test_df[["date"] + segment_dummy_cols].copy()
    test_predictions_df["actual"] = y_test.values
    test_predictions_df["predicted"] = y_pred_best
    test_predictions_df["residual"] = y_test.values - y_pred_best
    test_predictions_df["segment"] = test_predictions_df[segment_dummy_cols].idxmax(axis=1).str.replace("segment_", "", regex=False)

    return {
        "final_model": final_model,
        "feature_cols": feature_cols,
        "segment_dummy_cols": segment_dummy_cols,
        "model_df": model_df,
        "feat_df": feat_df,
        "recommended_model_name": recommended_model_name,
        "final_comparison": final_comparison,
        "cv_summary": cv_summary,
        "baseline_results": pd.DataFrame(baseline_results).T.round(3),
        "final_metrics_best": final_metrics_best,
        "residual_std": residual_std,
        "importances": importances,
        "segment_metrics_df": segment_metrics_df,
        "test_predictions_df": test_predictions_df,
        "cutoff_date": cutoff_date,
        "xgb_available": XGB_AVAILABLE,
        "lgb_available": LGB_AVAILABLE,
    }


# --------------------------------------------------------------------------
# Inference: single-step and recursive multi-step forecasting
# (identical logic to notebook Sections 14 & 18)
# --------------------------------------------------------------------------
def recursive_forecast(model, model_df, feature_cols, segment_dummy_cols, segment_name,
                        n_months, residual_std):
    """
    Recursively forecast `n_months` ahead for a single segment.
    Mirrors notebook Section 14's `recursive_forecast` exactly: each future month's
    prediction feeds the lag/rolling features for the next step, and exogenous
    (non-revenue) drivers are held at their last known values.
    """
    seg_col = f"segment_{segment_name}"
    hist = model_df[model_df[seg_col] == 1].sort_values("date").reset_index(drop=True).copy()
    if hist.empty:
        raise ValueError(f"No engineered history available for segment '{segment_name}'.")

    last_row = hist.iloc[-1].copy()
    revenue_history = hist["monthly_revenue_usd"].tolist()

    forecasts = []
    current_date = last_row["date"]

    for step in range(1, n_months + 1):
        current_date = current_date + pd.DateOffset(months=1)

        new_row = last_row.copy()
        new_row["date"] = current_date
        new_row["year"] = current_date.year
        new_row["month"] = current_date.month
        new_row["quarter"] = current_date.quarter
        new_row["month_number"] = current_date.month
        new_row["quarter_number"] = current_date.quarter
        new_row["time_index"] = last_row["time_index"] + step

        new_row["monthly_revenue_usd"] = revenue_history[-1]

        for lag in [1, 2, 3, 6, 12]:
            new_row[f"revenue_lag_{lag}"] = (
                revenue_history[-lag] if len(revenue_history) >= lag else revenue_history[0]
            )

        recent = pd.Series(revenue_history)
        new_row["revenue_rolling_mean_3"] = recent.tail(3).mean()
        new_row["revenue_rolling_mean_6"] = recent.tail(6).mean()
        new_row["revenue_rolling_mean_12"] = recent.tail(12).mean()
        new_row["revenue_rolling_std_3"] = recent.tail(3).std()
        new_row["revenue_rolling_std_6"] = recent.tail(6).std()

        new_row["revenue_growth_1m"] = (revenue_history[-1] / revenue_history[-2] - 1) if len(revenue_history) >= 2 else 0
        new_row["revenue_growth_3m"] = (revenue_history[-1] / revenue_history[-4] - 1) if len(revenue_history) >= 4 else 0
        new_row["subscriber_growth"] = 0.0
        new_row["marketing_spend_growth"] = 0.0

        X_new = pd.DataFrame([new_row])[feature_cols]
        pred = float(model.predict(X_new)[0])

        horizon_std = residual_std * np.sqrt(step)
        forecasts.append({
            "segment": segment_name,
            "forecast_month": current_date,
            "predicted_revenue": pred,
            "lower_bound": pred - 1.28 * horizon_std,   # ~80% prediction interval
            "upper_bound": pred + 1.28 * horizon_std,
        })

        revenue_history.append(pred)
        last_row = new_row

    return pd.DataFrame(forecasts)


def forecast_all_segments(model, model_df, feature_cols, segment_dummy_cols, n_months, residual_std):
    segment_names = [c.replace("segment_", "") for c in segment_dummy_cols]
    frames = [
        recursive_forecast(model, model_df, feature_cols, segment_dummy_cols, seg, n_months, residual_std)
        for seg in segment_names
    ]
    return pd.concat(frames, ignore_index=True)
