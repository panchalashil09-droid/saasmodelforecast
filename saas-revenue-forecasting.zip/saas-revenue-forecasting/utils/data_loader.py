"""Data loading, caching, and lightweight aggregation helpers for the dashboard."""

import os
import pandas as pd
import streamlit as st

DATA_PATH = "simulated_saas_subscription_revenue_data.csv"
SEGMENTS = ["AI_Assistant", "Streaming", "Telecom_Hosting"]


@st.cache_data(show_spinner=False)
def load_data(path: str = DATA_PATH) -> pd.DataFrame:
    """Load and lightly clean the raw SaaS subscription dataset."""
    if not os.path.exists(path):
        raise FileNotFoundError(
            f"Could not find '{path}'. Please make sure the dataset CSV is in the "
            "application directory."
        )
    df = pd.read_csv(path)
    df["date"] = pd.to_datetime(df["date"])
    df = df.sort_values(["segment", "date"]).reset_index(drop=True)
    return df


@st.cache_data(show_spinner=False)
def filter_data(df: pd.DataFrame, segment: str, start_date, end_date) -> pd.DataFrame:
    """Filter by segment (or 'All Segments') and date range."""
    mask = (df["date"] >= pd.Timestamp(start_date)) & (df["date"] <= pd.Timestamp(end_date))
    filtered = df[mask]
    if segment != "All Segments":
        filtered = filtered[filtered["segment"] == segment]
    return filtered.reset_index(drop=True)


@st.cache_data(show_spinner=False)
def latest_company_snapshot(df: pd.DataFrame) -> dict:
    """Aggregate the latest month's figures across all segments (company-wide)."""
    latest_date = df["date"].max()
    prev_date = sorted(df["date"].unique())[-2] if df["date"].nunique() > 1 else latest_date

    latest = df[df["date"] == latest_date]
    prev = df[df["date"] == prev_date]

    current_revenue = latest["monthly_revenue_usd"].sum()
    prev_revenue = prev["monthly_revenue_usd"].sum()
    revenue_growth = (current_revenue / prev_revenue - 1) * 100 if prev_revenue else 0.0

    active_subscribers = latest["active_subscribers"].sum()
    prev_subscribers = prev["active_subscribers"].sum()
    subscriber_growth = (active_subscribers / prev_subscribers - 1) * 100 if prev_subscribers else 0.0

    # Company ARPU = total revenue / total subscribers (weighted, not a simple average)
    arpu = current_revenue / active_subscribers if active_subscribers else 0.0
    prev_arpu = prev_revenue / prev_subscribers if prev_subscribers else 0.0
    arpu_delta = (arpu / prev_arpu - 1) * 100 if prev_arpu else 0.0

    nps = latest["nps_score"].mean()
    prev_nps = prev["nps_score"].mean()

    churn = latest["churn_rate_pct"].mean()
    prev_churn = prev["churn_rate_pct"].mean()

    return {
        "latest_date": latest_date,
        "prev_date": prev_date,
        "current_revenue": current_revenue,
        "prev_revenue": prev_revenue,
        "revenue_growth": revenue_growth,
        "active_subscribers": int(active_subscribers),
        "subscriber_growth": subscriber_growth,
        "arpu": arpu,
        "arpu_delta": arpu_delta,
        "nps": nps,
        "nps_delta": (nps - prev_nps) if pd.notna(nps) and pd.notna(prev_nps) else 0.0,
        "churn": churn,
        "churn_delta": (churn - prev_churn) if pd.notna(churn) and pd.notna(prev_churn) else 0.0,
    }


def format_currency(value, compact=True):
    """Format a dollar figure, compact (e.g. $2.84M) or full."""
    if pd.isna(value):
        return "N/A"
    sign = "-" if value < 0 else ""
    value = abs(value)
    if not compact:
        return f"{sign}${value:,.0f}"
    if value >= 1_000_000_000:
        return f"{sign}${value / 1_000_000_000:.2f}B"
    if value >= 1_000_000:
        return f"{sign}${value / 1_000_000:.2f}M"
    if value >= 1_000:
        return f"{sign}${value / 1_000:.1f}K"
    return f"{sign}${value:,.0f}"
